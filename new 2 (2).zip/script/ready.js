
// 헤더 푸터 불러오기 //
$(document).ready(function () {
    $('#header').load('/header.html');
    $('#footer').load('/footer.html');
})